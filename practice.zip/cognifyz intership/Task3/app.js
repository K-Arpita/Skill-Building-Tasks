const express = require('express');
const app = express();
const path = require('path');

// Set the view engine to EJS
app.set('view engine', 'ejs');

// Set the views folder (this is where your EJS templates will reside)
app.set('views', path.join(__dirname, 'views'));

// Serve static files (CSS, images, JS, etc.)
app.use(express.static(path.join(__dirname, 'public')));

// Home route
app.get('/', (req, res) => {
  res.render('index');  // Render the 'index.ejs' file from the 'views' folder
});

// Start the server
const port = 5000;
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
