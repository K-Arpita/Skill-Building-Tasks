// Import required modules
const express = require('express');
const path = require('path');

// Create an Express app
const app = express();

// Set EJS as the view engine
app.set('view engine', 'ejs');

// Set up static files (optional if you have any)
app.use(express.static(path.join(__dirname, 'public')));

// Body parser middleware to handle POST data (if needed)
app.use(express.urlencoded({ extended: true }));

// Route for the home page (index.ejs)
app.get('/', (req, res) => {
  res.render('index'); // This will render the index.ejs file
});

// Route to handle form submission (POST request)
app.post('/submit', (req, res) => {
  // Get data from form submission
  const { name, email, phone, age, gender, terms } = req.body;
  
  // For now, we'll just send the data back as a response
  res.send(`
    <h2>Form Submitted Successfully</h2>
    <p>Name: ${name}</p>
    <p>Email: ${email}</p>
    <p>Phone : ${phone}</p>
    <p>Age: ${age}</p>
    <p>Gender: ${gender}</p>
    <p>Terms Accepted: ${terms ? 'Yes' : 'No'}</p>
  `);
});

// Start the server on port 3000
const port = 3000;
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});