// Import required modules
const express = require('express');
const path = require('path');

const app = express();
const PORT = 4000;

// Middleware for parsing request bodies
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files (CSS, JS, Images)
app.use(express.static(path.join(__dirname, 'public')));

// Set up EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Route to render the main page
app.get('/', (req, res) => {
    res.render('index'); // Renders index.ejs
});

// Route to handle form submission
app.post('/submit', (req, res) => {
    const { email, password, confirmPassword } = req.body;

    let errorMessages = [];

    // Email validation
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailPattern.test(email)) {
        errorMessages.push('Please enter a valid email address.');
    }

    // Password strength validation
    const passwordPattern = /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*?&]).{8,}$/;
    if (!passwordPattern.test(password)) {
        errorMessages.push('Password must be at least 8 characters long and contain an uppercase letter, a lowercase letter, a digit, and a special character.');
    }

    // Confirm password validation
    if (password !== confirmPassword) {
        errorMessages.push('Passwords do not match.');
    }

    // If validation fails, re-render with errors
    if (errorMessages.length > 0) {
        return res.render('index', { errorMessages });
    }

    // If successful, render success message
    res.render('success', { email });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
