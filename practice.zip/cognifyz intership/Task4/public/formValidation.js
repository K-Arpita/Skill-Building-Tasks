document.getElementById('signupForm').addEventListener('submit', function(event) {
    event.preventDefault(); 

    document.getElementById('errorMessages').innerHTML = 'invalid';
  
   
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const agreeTerms = document.getElementById('agreeTerms').checked;
  
    let errorMessages = [];
  
    
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailPattern.test(email)) {
      errorMessages.push('Please enter a valid email address.');
    }
  
    
    const passwordPattern = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d@$!%*?&]{8,}$/;
    if (!passwordPattern.test(password)) {
      errorMessages.push('Password must be at least 8 characters long, containing both letters and numbers.');
    }
  
    
    if (password !== confirmPassword) {
      errorMessages.push('Passwords do not match.');
    }
  
    
    if (!agreeTerms) {
      errorMessages.push('You must agree to the terms.');
    }
  
    
    if (errorMessages.length > 0) {
      document.getElementById('errorMessages').innerHTML = errorMessages.join('<br>');
    } else {
      
      alert('Form Submitted Successfully!');
    }
  });
  