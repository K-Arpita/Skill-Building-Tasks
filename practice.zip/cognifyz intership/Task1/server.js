const express = require('express');
const bodyParser = require('body-parser');

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));

// Set EJS as the template engine
app.set('view engine', 'ejs');

// Serve static files from the "public" folder (optional)
app.use(express.static('public'));

// Route to render the form (index.ejs)
app.get('/', (req, res) => {
  res.render('index');  // Render the 'index.ejs' file
});

// Route to handle form submission
app.post('/submit', (req, res) => {
  const { name, email } = req.body;  // Extract form data
  res.render('response', { name, email });  // Render response.ejs with data
});

// Start the server and listen on port 3000
const PORT = 1000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});