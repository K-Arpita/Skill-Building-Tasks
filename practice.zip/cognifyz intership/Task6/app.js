const express = require('express');
const jwt = require('jsonwebtoken');
const path = require('path'); // Import the path module

const app = express();
const PORT = 3000;
const SECRET_KEY = 'your_secret_key';

// Middleware to parse JSON and URL-encoded form data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from the "public" directory
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
  });

  const VALID_USERNAME = 'admin';
  const VALID_PASSWORD = 'password';


// POST route for login
app.post('/login', (req, res) => {
    const { username, password } = req.body;

   
    if (username === VALID_USERNAME && password === VALID_PASSWORD) {
    const token = jwt.sign({ username }, SECRET_KEY, { expiresIn: '1h' });
    res.status(200).json({ message: 'Login successful', token });
    }

    res.status(401).json({ message: 'Invalid username or password' });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server running on If you visit http://localhost:3000/login.html`);
});
