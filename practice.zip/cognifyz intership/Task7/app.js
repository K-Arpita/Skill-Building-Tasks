// app.js
const express = require('express');
const passport = require('passport');
const OAuth2Strategy = require('passport-oauth2').Strategy;
const axios = require('axios');
const dotenv = require('dotenv');

dotenv.config();

const app = express();

// Serve static files (like CSS) from the 'public' directory
app.use(express.static('public'));

// Set up Passport OAuth2 strategy
passport.use(new OAuth2Strategy({
  authorizationURL: 'https://accounts.google.com/o/oauth2/v2/auth',
  tokenURL: 'https://oauth2.googleapis.com/token',
  clientID: process.env.CLIENT_ID,
  clientSecret: process.env.CLIENT_SECRET,
  callbackURL: process.env.REDIRECT_URI
}, (accessToken, refreshToken, profile, done) => {
  return done(null, { accessToken, profile });
}));

// Initialize passport
app.use(passport.initialize());

// Endpoint to start OAuth flow
app.get('/auth', passport.authenticate('oauth2'));

// OAuth callback endpoint
app.get('/callback', passport.authenticate('oauth2', { failureRedirect: '/' }), (req, res) => {
  res.redirect('/profile');
});

// Profile endpoint to show user data
app.get('/profile', (req, res) => {
  if (!req.user) {
    return res.redirect('/');
  }

  // Make an authenticated request to an external API (Google API for example)
  axios.get('https://www.googleapis.com/drive/v3/files', {
    headers: {
      Authorization: `Bearer ${req.user.accessToken}`
    }
  })
    .then(response => {
      res.send(`
        <div class="container">
          <h1>Google Drive Files</h1>
          <div class="profile-info">
            <h3>User Profile</h3>
            <pre>${JSON.stringify(req.user.profile, null, 2)}</pre>
            <h3>Files:</h3>
            <pre>${JSON.stringify(response.data.files, null, 2)}</pre>
          </div>
        </div>
      `);
    })
    .catch(error => {
      res.status(500).json({ error: 'Failed to fetch data from API', details: error });
    });
});

// Home route
app.get('/', (req, res) => {
  res.send(`
    <div class="container">
      <h1>OAuth 2.0 Integration</h1>
      <a href="/auth">Login with Google</a>
    </div>
  `);
});

// Start the server
app.listen(3000, () => {
  console.log('Server running at http://localhost:3000');
});
