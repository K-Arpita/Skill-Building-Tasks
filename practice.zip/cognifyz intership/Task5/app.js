const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();

// Middleware
app.use(bodyParser.json());
app.use(cors());

// Sample data (in-memory for demo purposes)
let data = [
    { id: 1, name: 'Item 1', description: 'Description 1' },
    { id: 2, name: 'Item 2', description: 'Description 2' }
];

app.post('/api/items', (req, res) => {
    const newItem = { id: Date.now(), ...req.body }; // Generate unique ID
    data.push(newItem); // Add to in-memory data
    res.status(201).json(newItem); // Respond with the newly created item
});

app.get('/api/items', (req, res) => {
    res.json(data); // Return all items
});


app.get('/api/items/:id', (req, res) => {
    const item = data.find(d => d.id === parseInt(req.params.id)); // Find item by ID
    if (item) {
        res.json(item); // Return the found item
    } else {
        res.status(404).json({ message: 'Item not found' }); // Respond with an error if not found
    }
});

// Delete (DELETE): Remove an item by ID
app.delete('/api/items/:id', (req, res) => {
    const id = parseInt(req.params.id); // Parse ID from request
    const index = data.findIndex(item => item.id === id); // Find index of the item

    if (index !== -1) {
        data.splice(index, 1); // Remove item from array
        res.status(200).json({ message: 'Item deleted successfully' });
    } else {
        res.status(404).json({ message: 'Item not found' });
    }
});


const path = require('path');

// Serve static files from the public directory
app.use(express.static(path.join(__dirname, 'public')));

const PORT = 5000;
app.listen(PORT, () => console.log(`http://localhost:${PORT}`));
