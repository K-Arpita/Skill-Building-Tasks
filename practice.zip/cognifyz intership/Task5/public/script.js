// Base API URL
const API_URL = 'http://localhost:5000/api/items';

// Select DOM elements
const createForm = document.getElementById('create-form');
const itemList = document.getElementById('item-list');

// Function to fetch and display items
async function fetchItems() {
    try {
        const response = await fetch(API_URL);
        const items = await response.json();

        // Clear current list
        itemList.innerHTML = '';

        // Populate list with items and add Delete button
        items.forEach(item => {
            const li = document.createElement('li');
            li.textContent = `${item.name}: ${item.description}`;

            // Create Delete button
            const deleteButton = document.createElement('button');
            deleteButton.textContent = 'Delete';
            deleteButton.style.marginLeft = '10px';

            // Add event listener for delete
            deleteButton.addEventListener('click', () => deleteItem(item.id));

            // Append button to the list item
            li.appendChild(deleteButton);

            // Add list item to the DOM
            itemList.appendChild(li);
        });
    } catch (error) {
        console.error('Error fetching items:', error);
    }
}

// Function to delete an item
async function deleteItem(itemId) {
    try {
        const response = await fetch(`${API_URL}/${itemId}`, {
            method: 'DELETE',
        });

        if (response.ok) {
            // Refresh the list after deletion
            fetchItems();
        } else {
            console.error('Failed to delete item');
        }
    } catch (error) {
        console.error('Error deleting item:', error);
    }
}

// Handle form submission to create a new item
createForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const name = document.getElementById('name').value;
    const description = document.getElementById('description').value;

    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, description }),
        });

        if (response.ok) {
            // Clear form fields
            createForm.reset();

            // Refresh the item list
            fetchItems();
        }
    } catch (error) {
        console.error('Error creating item:', error);
    }
});

async function fetchItems() {
    try {
        const response = await fetch(API_URL);
        const items = await response.json();

        // Clear current list
        itemList.innerHTML = '';

        // Populate list with items and add Delete button
        items.forEach(item => {
            const card = document.createElement('div');
            card.classList.add('card');

            // Add content to the card
            card.innerHTML = `
                <h3>${item.name}</h3>
                <p>${item.description}</p>
            `;

            // Create Delete button
            const deleteButton = document.createElement('button');
            deleteButton.textContent = 'Delete';

            // Add event listener for delete
            deleteButton.addEventListener('click', () => deleteItem(item.id));

            // Append the Delete button to the card
            card.appendChild(deleteButton);

            // Append the card to the list
            itemList.appendChild(card);
        });
    } catch (error) {
        console.error('Error fetching items:', error);
    }
}

// Fetch items on page load
fetchItems();
