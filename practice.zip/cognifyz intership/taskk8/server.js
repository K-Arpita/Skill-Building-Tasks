const express = require('express');
const morgan = require('morgan');
const bodyParser = require('body-parser');

const app = express();

// Middleware for logging requests
app.use(morgan('combined'));

// Middleware for parsing JSON request bodies
app.use(bodyParser.json());

// Middleware for parsing URL-encoded data
app.use(bodyParser.urlencoded({ extended: true }));

// Example route
app.get('/', (req, res) => {
  res.send('Middleware setup is complete!');
});

// Error-handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send('Something went wrong!');
});

// Start the server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
